INITIAL_HANDLER("TestingGUI.cpp")

WINDOW_TITLE("The Adventures of Links")

TEST_ORDER("Labyrinth.cpp", "LabyrinthEscape.cpp", "SplicingAndDicing.cpp")
