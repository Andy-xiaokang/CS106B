#ifndef Permutations_Included
#define Permutations_Included

#include <string>
#include "set.h"

Set<std::string> permutationsOf(const std::string& str);

#endif
