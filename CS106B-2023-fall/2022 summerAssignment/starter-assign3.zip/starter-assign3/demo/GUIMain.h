#pragma once

/* Locks/unlocks all demo option buttons. Should only be called from the main GUI thread. */
void setDemoOptionsEnabled(bool isEnabled);

void runInteractiveDemo();

