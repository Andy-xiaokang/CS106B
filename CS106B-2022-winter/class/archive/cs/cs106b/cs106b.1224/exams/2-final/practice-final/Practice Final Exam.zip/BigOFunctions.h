#pragma once

void iterativePrinting(int n);
void iterativePQ(int n);
void iterativeHashSet(int n);
void iterativeLooping(int n);
void iterativeVector(int n);
