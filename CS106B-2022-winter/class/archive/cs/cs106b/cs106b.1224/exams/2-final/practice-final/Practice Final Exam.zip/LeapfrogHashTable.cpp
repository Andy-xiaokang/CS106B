#include "LeapfrogHashTable.h"
using namespace std;

LeapfrogHashTable::LeapfrogHashTable(HashFunction<string> hashFn) {
    /* TODO: Delete this comment and the line below it, then implement this function. */
    (void) hashFn;
}

LeapfrogHashTable::~LeapfrogHashTable() {
    /* TODO: Delete this comment, then implement this function. */
}

bool LeapfrogHashTable::contains(const string& key) const {
    /* TODO: Delete this comment and the lines below it, then implement this function. */
    (void) key;
    return false;
}

bool LeapfrogHashTable::insert(const string& key) {
    /* TODO: Delete this comment and the lines below it, then implement this function. */
    (void) key;
    return false;
}

int LeapfrogHashTable::size() const {
    /* TODO: Delete this comment and the line below it, then implement this function. */
    return -1;
}

bool LeapfrogHashTable::isEmpty() const {
    /* TODO: Delete this comment and the line below it, then implement this function. */
    return false;
}

void LeapfrogHashTable::printDebugInfo() const {
    /* TODO: Delete this comment, then optionally add code to this function. */
}

/************************************************************************
 * You are encouraged to - but not required to - add custom tests here. *
 ************************************************************************/

#include "GUI/SimpleTest.h"
