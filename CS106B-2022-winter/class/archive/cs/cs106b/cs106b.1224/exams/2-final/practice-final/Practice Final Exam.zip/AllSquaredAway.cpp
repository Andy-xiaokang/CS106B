#include "vector.h"
using namespace std;

/* We've provided this function to you; you don't need to implement it. */
bool isPerfectSquare(int value);

bool hasSquareSequence(int n, Vector<int>& sequence) {
    /* TODO: Delete this line and the lines below it, then implement this function. */
    (void) n;
    (void) sequence;
    return false;
}

/************************************************************************
 * You are encouraged to - but not required to - add custom tests here. *
 ************************************************************************/

#include "GUI/SimpleTest.h"
