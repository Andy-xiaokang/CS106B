#pragma once
#include <string>

struct Cell {
    int value;
    Cell *next;
};
